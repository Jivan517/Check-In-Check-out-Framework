/**
 * Copyright 2016 the original author or authors.
 * 
 * Licensed under the MIT License (MIT);
 */
package cs525.rentalcarsystem.model;

/**
 * @author paudelumesh
 *
 */
public class CheckinCart {

}
