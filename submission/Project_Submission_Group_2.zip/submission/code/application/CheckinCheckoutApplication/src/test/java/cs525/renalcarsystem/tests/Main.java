package cs525.renalcarsystem.tests;

public class Main {

}
