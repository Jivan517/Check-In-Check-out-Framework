/*
 * Copyright 2016 the original author or authors.
 *
 * Licensed under the MIT License (MIT);
 * 
 */
package cs525.project.fujframework.middleware;

/**
 * provides a class for sending text message
 * 
 * @author Jivan Nepali
 * 
 * @version 1.0.0
 *
 */
public class TextMessageSender implements MessageSender {

	@Override
	public void sendMessage(String body, Person person) {
		// TODO Auto-generated method stub

	}

}
