package cs525.project.fujframework.utils;

public interface ConfigProperties {

	String readProperty(String propertyName);
}
