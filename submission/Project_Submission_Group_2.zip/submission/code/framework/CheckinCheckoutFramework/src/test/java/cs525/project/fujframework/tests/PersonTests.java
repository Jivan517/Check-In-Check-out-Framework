package cs525.project.fujframework.tests;


public class PersonTests {

}
